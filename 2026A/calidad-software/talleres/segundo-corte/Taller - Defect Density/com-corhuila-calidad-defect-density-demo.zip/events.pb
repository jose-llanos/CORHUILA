p
26.3.0.120487$39a5b623-d821-440f-aa6c-496e80a9468b"
SQ Upgrade8��ʾ�3B$13461fdb-b036-454e-8de7-0b35e28dc1e4u
Use "Sonar way" (xml)$0bcb5ad0-ed3a-4d05-aa8c-3d8ba21853d6"Profile8�Ҷ��3B$5bd11824-df0a-4c0e-8254-8e4edaddb9e8
Failed$0bcb5ad0-ed3a-4d05-aa8c-3d8ba21853d6"Alert*Coverage on New Code < 808�Ҷ��3B$d4e42743-7705-46b1-94a7-bf09239d54dbe
1.0.0$70acea4f-1636-41be-812d-45c7f654a763"Version8�����3B$0781c7ae-f696-49fb-89d0-49da88115d29