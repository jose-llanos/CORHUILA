package com.corhuila.calidad;

public class BankAccount {

    private double balance;
    private final String accountNumber; // final: el número de cuenta no debería cambiar

    // CORRECCIÓN 7: Eliminado campo público mutable.
    // Exponer estado interno directamente rompe el encapsulamiento

    public BankAccount(String accountNumber, double initialBalance) {
        if (accountNumber == null || accountNumber.isBlank()) {
            throw new IllegalArgumentException("El número de cuenta no puede ser vacío.");
        }
        if (initialBalance < 0) {
            throw new IllegalArgumentException("El saldo inicial no puede ser negativo.");
        }
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
    }

    // CORRECCIÓN 8: La lógica ahora es coherente.
    // Si el monto es inválido, se lanza excepción y NO se modifica el saldo.
    public void deposit(double amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("El monto a depositar debe ser mayor a cero.");
        }
        balance += amount;
    }

    // CORRECCIÓN 9: Comparación de Strings con equals(), no con ==.
    // == compara referencias en memoria, equals() compara el contenido.
    public boolean isSameAccount(BankAccount other) {
        if (other == null) return false;
        return this.accountNumber.equals(other.accountNumber);
    }

    // CORRECCIÓN 10: Eliminada variable 'temp' que nunca se usaba (código muerto).
    public double getBalance() {
        return balance;
    }

}