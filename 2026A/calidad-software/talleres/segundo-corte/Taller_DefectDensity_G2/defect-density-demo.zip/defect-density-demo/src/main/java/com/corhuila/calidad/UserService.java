package com.corhuila.calidad;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Logger;

public class UserService {

    private static final Logger logger = Logger.getLogger(UserService.class.getName());

    private final List<String> users = new ArrayList<>();

    public boolean validateUser(String username) {
        if (username == null || !username.matches("[a-zA-Z0-9_]+")) {
            return false;
        }
        return true;
    }

    public String processUser(String user) {
        if (user == null || user.isEmpty()) {
            return "UNKNOWN";
        }

        boolean isAdmin = user.contains("admin");
        boolean isTest  = user.contains("test");
        boolean isProd  = user.contains("prod");

        if (isAdmin && isTest && isProd) return "ADMIN_TEST_PROD";
        if (isAdmin && isTest)           return "ADMIN_TEST";
        if (isAdmin)                     return "ADMIN";

        return "USER";
    }

    public void addUser(String username) {
        if (username == null || username.isBlank()) {
            throw new IllegalArgumentException("El username no puede ser nulo o vacío.");
        }
        try {
            Integer.parseInt(username);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("El username debe ser numérico: " + username, e);
        }
        users.add(username);
    }

    // IOException en lugar de Exception genérico
    public String readUserFile(String path) throws IOException {
        try (var lines = Files.lines(Paths.get(path))) {
            // Logger en lugar de System.out
            lines.forEach(line -> logger.info(line));
        }
        return "File read";
    }

    public List<String> getUsers() {
        return Collections.unmodifiableList(users);
    }
}